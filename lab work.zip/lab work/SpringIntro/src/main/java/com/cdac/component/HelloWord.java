package com.cdac.component;

public class HelloWord {

	
		public String sayHello(String name){
			return "Hello"+name;
		}
		
	}
