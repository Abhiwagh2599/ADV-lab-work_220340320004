package com.cdac.component;

import java.util.List;

public interface CarPartsInventory {
	public void addCarParts(CarParts cp);
	public List<CarParts>getCarParts();
}
